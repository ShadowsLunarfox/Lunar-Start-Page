// Small utility helpers.
function ownsInterfaceStorageKey(key) {
  if (typeof key !== "string") return false;
  if (STORAGE_KEY === "customHomeStateLegacy") return key === STORAGE_KEY || key.startsWith("legacy:") || key.startsWith(LANGUAGE_CACHE_PREFIX);
  return key === STORAGE_KEY || key === "lunarWindowsMediaWidget:v1" || key === BROWSER_PREFLIGHT_CACHE_KEY || key === FIREFOX_COMPAT_NOTICE_ACK_KEY
    || key.startsWith(BROWSER_COMPAT_NOTICE_ACK_PREFIX)
    || (key.startsWith(LANGUAGE_CACHE_PREFIX) && !key.startsWith("language:legacy:"));
}

function clearInterfaceLocalStorage() {
  const keys = Array.from({ length: localStorage.length }, (_, index) => localStorage.key(index)).filter(ownsInterfaceStorageKey);
  keys.forEach(key => localStorage.removeItem(key));
}

function openDialog(id) {
  document.getElementById(id).showModal();
}

function closeDialog(id) {
  document.getElementById(id).close();
}

function bindOptionalEvent(element, eventName, handler) {
  if (!element || typeof element.addEventListener !== "function" || typeof handler !== "function") return;
  element.addEventListener(eventName, handler);
}

function bindOptionalClick(element, handler) {
  bindOptionalEvent(element, "click", handler);
}

function bindDialogBackdropClose(dialog) {
  if (!dialog || dialog.dataset.backdropCloseBound === "true") return;
  if (dialog.dataset.backdropClose === "false") return;

  dialog.addEventListener("click", (event) => {
    if (event.target !== dialog) return;
    const rect = dialog.getBoundingClientRect();
    const clickedInsideDialog = (
      event.clientX >= rect.left
      && event.clientX <= rect.right
      && event.clientY >= rect.top
      && event.clientY <= rect.bottom
    );

    if (!clickedInsideDialog) {
      dialog.close();
    }
  });

  dialog.dataset.backdropCloseBound = "true";
}

function normalizeUrl(url) {
  if (/^https?:\/\//i.test(url)) return url;
  return `https://${url}`;
}

function stripProtocol(url) {
  return url.replace(/^https?:\/\//i, "").replace(/\/$/, "");
}

function faviconForUrl(url) {
  try {
    const target = new URL(normalizeUrl(url));
    const bundledIcons = {
      "zh.wikifur.com": "wiki",
      "www.furrycons.cn": "calendar",
      "www.wilddream.net": "art",
      "hi-furry.cn": "paw",
      "www.infurnity.com": "star",
      "furrymosa.gjs.tw": "book",
      "furrycons.com": "calendar",
      "www.instagram.com": "camera",
      "www.facebook.com": "people",
      "www.youtube.com": "video",
      "x.com": "chat"
    };
    const icon = bundledIcons[target.hostname.toLowerCase()];
    if (icon) return "resource/icons/furry/" + icon + ".svg";

    return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(target.hostname)}&sz=64`;
  } catch {
    return "";
  }
}

function findLinkById(id) {
  return state.links.find((link) => link.id === id) || null;
}

function normalizeHexColor(value, fallback) {
  if (typeof value !== "string") return fallback;
  const hex = value.trim();
  if (/^#[0-9a-fA-F]{6}$/.test(hex)) return hex.toLowerCase();
  return fallback;
}

function resolveThemeColor(value, theme, defaults) {
  const normalized = normalizeHexColor(value, defaults[theme]);
  // Saved defaults follow the display mode; explicit custom colors are retained.
  return normalized === defaults.dark || normalized === defaults.light ? defaults[theme] : normalized;
}

function resolveThemeTextColor(value, theme) {
  return resolveThemeColor(value, theme, THEME_TEXT_DEFAULTS);
}

function clampNumber(value, min, max, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(max, Math.max(min, Math.round(number)));
}

function clampValue(value, min, max, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(max, Math.max(min, number));
}

function hexToRgb(hex) {
  const safeHex = normalizeHexColor(hex, "#000000").slice(1);
  return {
    r: parseInt(safeHex.slice(0, 2), 16),
    g: parseInt(safeHex.slice(2, 4), 16),
    b: parseInt(safeHex.slice(4, 6), 16)
  };
}

function rgbToHex({ r, g, b }) {
  const safe = [r, g, b].map((channel) => Math.max(0, Math.min(255, Math.round(channel))));
  return `#${safe.map((channel) => channel.toString(16).padStart(2, "0")).join("")}`;
}

function mixHex(colorA, colorB, ratio) {
  const a = hexToRgb(colorA);
  const b = hexToRgb(colorB);
  const blend = Math.max(0, Math.min(1, Number(ratio) || 0));
  return rgbToHex({
    r: a.r + ((b.r - a.r) * blend),
    g: a.g + ((b.g - a.g) * blend),
    b: a.b + ((b.b - a.b) * blend)
  });
}

function pickReadableTextColor(hex) {
  const { r, g, b } = hexToRgb(hex);
  const luminance = (0.299 * r) + (0.587 * g) + (0.114 * b);
  return luminance > 165 ? "#111827" : "#f9fbff";
}

function escapeHtml(value) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function escapeAttribute(value) {
  return escapeHtml(value);
}
