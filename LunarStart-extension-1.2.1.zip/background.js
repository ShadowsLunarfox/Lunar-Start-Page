const CONTEXT_MENU_ID = "save-page-to-lunar-start";
const CONTEXT_MENU_TITLE = "Save This Page to Lunar Start";
const PENDING_LINK_KEY_PREFIX = "pendingSavedLink:";
const extensionApi = getExtensionApi();
const contextMenusApi = getContextMenusApi();

extensionApi?.runtime?.onInstalled?.addListener(() => {
  ensureContextMenu();
});

extensionApi?.runtime?.onStartup?.addListener(() => {
  ensureContextMenu();
});

contextMenusApi?.onClicked?.addListener((info, tab) => {
  const pageUrl = tab?.url || info?.pageUrl || "";
  if (info.menuItemId !== CONTEXT_MENU_ID || !pageUrl) return;
  if (!/^https?:/i.test(pageUrl)) return;

  void queueSavedLink({
    id: crypto.randomUUID(),
    name: sanitizeTitle(tab?.title) || deriveNameFromUrl(pageUrl),
    url: pageUrl,
    pinned: false
  });
});

function ensureContextMenu() {
  if (!contextMenusApi) return;

  void removeContextMenu(CONTEXT_MENU_ID).then(createContextMenu);
}

function createContextMenu() {
  if (!contextMenusApi?.create) return Promise.resolve();

  const item = {
    id: CONTEXT_MENU_ID,
    title: CONTEXT_MENU_TITLE,
    contexts: ["page"]
  };

  return new Promise((resolve) => {
    const finish = () => {
      clearExtensionRuntimeError();
      resolve();
    };

    try {
      const result = contextMenusApi.create(item, finish);
      if (isPromiseLike(result)) {
        result.then(resolve, resolve);
      } else if (contextMenusApi.create.length < 2) {
        finish();
      }
    } catch {
      resolve();
    }
  });
}

async function queueSavedLink(link) {
  // Deliver one durable record to each interface; each acknowledges only its own copy.
  // Unique keys also prevent rapid saves from overwriting a shared ID index.
  await extensionStorageSet({
    [`${PENDING_LINK_KEY_PREFIX}${link.id}`]: link,
    [`legacy:${PENDING_LINK_KEY_PREFIX}${link.id}`]: link
  });
}

function getExtensionApi() {
  if (typeof browser !== "undefined") return browser;
  if (typeof chrome !== "undefined") return chrome;
  return null;
}

function getContextMenusApi() {
  return extensionApi?.contextMenus || extensionApi?.menus || null;
}

function isPromiseExtensionApi() {
  return typeof browser !== "undefined" && extensionApi === browser;
}

function removeContextMenu(id) {
  if (!contextMenusApi?.remove) return Promise.resolve();

  return new Promise((resolve) => {
    const finish = () => {
      clearExtensionRuntimeError();
      resolve();
    };

    try {
      const result = contextMenusApi.remove(id, finish);
      if (isPromiseLike(result)) {
        result.then(resolve, resolve);
      } else if (contextMenusApi.remove.length < 2) {
        finish();
      }
    } catch {
      resolve();
    }
  });
}

function getExtensionRuntimeError() {
  return extensionApi?.runtime?.lastError || (typeof chrome !== "undefined" ? chrome.runtime?.lastError : null);
}

function clearExtensionRuntimeError() {
  getExtensionRuntimeError();
}

function isPromiseLike(value) {
  return Boolean(value) && typeof value.then === "function";
}

function extensionStorageGet(keys) {
  const storage = extensionApi?.storage?.local;
  if (!storage?.get) return Promise.resolve({});
  if (isPromiseExtensionApi()) {
    return storage.get(keys);
  }

  return new Promise((resolve) => {
    storage.get(keys, (items) => {
      resolve(items || {});
    });
  });
}

function extensionStorageSet(items) {
  const storage = extensionApi?.storage?.local;
  if (!storage?.set) return Promise.resolve();
  if (isPromiseExtensionApi()) {
    return storage.set(items);
  }

  return new Promise((resolve) => {
    storage.set(items, () => {
      resolve();
    });
  });
}

function sanitizeTitle(title) {
  if (typeof title !== "string") return "";
  return title.trim().replace(/\s+/g, " ").slice(0, 30);
}

function deriveNameFromUrl(url) {
  try {
    const target = new URL(url);
    return target.hostname.replace(/^www\./i, "");
  } catch {
    return "Saved Page";
  }
}

// Remove data and wake-up tasks left by the retired performance widget.
async function clearRetiredPerformanceData() {
  const features = ["system", "gpu"];
  const cleanup = [
    () => extensionApi?.storage?.local?.remove(features.map(feature => `lunarBackgroundWidget:v2:${feature}`)),
    () => extensionApi?.storage?.session?.remove(features.map(feature => `lunarWidgetLatest:v2:${feature}`)),
    () => extensionApi?.alarms?.clear("lunar-system-monitor-background")
  ];
  await Promise.allSettled(cleanup.map(async action => action()));
}
void clearRetiredPerformanceData();

if (typeof importScripts === "function") importScripts("script/widget-background-state.js", "script/windows-media-broker.js");
